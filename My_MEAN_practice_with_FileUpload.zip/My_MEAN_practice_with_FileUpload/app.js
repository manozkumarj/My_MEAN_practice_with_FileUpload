const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const cors = require("cors");
const mongoose = require("mongoose");
const expressValidator = require('express-validator');
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const multer = require('multer');

const User = require("./models/user");
const users = require("./routes/users");
const config = require("./config/database");

const app = express();
const port = 3000;



// Set The Storage Engine
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

// Init Upload
const upload = multer({
    storage: storage,
    limits: { fileSize: 1000000 },
    fileFilter: function (req, file, cb) {
        checkFileType(file, cb);
    }
}).single('myImage');

// Check File Type
function checkFileType(file, cb) {
    // Allowed ext
    const filetypes = /jpeg|jpg|png|gif/;
    // Check ext
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    // Check mime
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
        return cb(null, true);
    } else {
        cb('Error: Images Only!');
    }
}

app.set("view engine", "ejs");
app.set('views', path.join(__dirname, 'views'));

mongoose.connect(config.database);
mongoose.Promise = global.Promise;

mongoose.connection.on("connected", () => {
    console.log("WOW....! Connected to mongodb");
});

mongoose.connection.on("error", (err) => {
    console.log("Failed to connect to Mongodb : " + err);
});

// CORS Middleware
app.use(cors());

app.use(expressValidator({
    errorFormatter: function (param, msg, value) {
        var namespace = param.split('.')
            , root = namespace.shift()
            , formParam = root;

        while (namespace.length) {
            formParam += '[' + namespace.shift() + ']';
        }
        return {
            param: formParam,
            msg: msg,
            value: value
        };
    }
}));


// Set local variables
app.use(function (req, res, next) {
    res.locals.errors = null;
    res.locals.activeClass = "home";
    next();
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Users router
app.use("/users", users);
// Set Static Folder
app.use(express.static(path.join(__dirname, 'public')));

// Global end point
app.get("/", (req, res) => {
    // res.send("You are in Global area of this app...!");
    res.json({
        page: "Main Root",
        msg: "Welcome to root file"
    });
});



app.post('/upload', (req, res) => {
    console.log(req.body);
    upload(req, res, (err) => {
        if (err) {
            console.log("error in uploading");
            res.render('fileUpload', {
                msg: err
            });
        } else {
            if (req.file == undefined) {
                console.log("Error: No File Selected!");
                res.render('fileUpload', {
                    msg: 'Error: No File Selected!'
                });
            } else {
                console.log("File Uploaded!");
                res.render('fileUpload', {
                    msg: 'File Uploaded!',
                    file: `uploads/${req.file.filename}`
                });
            }
        }
    });
});


app.post(("/user/update"), uploadImg, (req, res) => {

    // console.log(req.body);
    let getId = req.body.id;
    console.log("Updatable user ID: " + getId);

    var newUser = {
        full_name: req.body.full_name,
        email: req.body.email,
        gender: req.body.gender,
        phone_number: req.body.phone_number,
    };

    User.findOneAndUpdate({ _id: getId }, { $set: newUser }, (err, data) => {
        if (err) {
            console.log("Failed, User updation has been failed.");
            res.json({
                success: false,
                message: "User updated failed...!"
            });
        } else {
            console.log("Success, user information updated successfully");
            // res.redirect("/users/edit/" + newUser.username);
            res.json({
                success: true,
                message: "User updated successfullyyy...!",
                user: data
            });
        }
    });

});

function uploadImg(req, res, next) {
    console.log(req.body);
    upload(req, res, (err) => {
        if (err) {
            console.log("error in uploading");
            res.json({
                success: false,
                message: "error in uploading"
            });
        } else {
            if (req.file == undefined) {
                res.json({
                    success: false,
                    message: "Error: No File Selected!"
                });
            } else {
                console.log("File Uploaded! \n" + req.file.filename);
                next();
            }
        }
    });
}





/* ********************************************** */










app.post("/register", (req, res) => {
    console.log(req.body);
    // res.send({ body: req.body });

    req.sanitize("full_name").trim();
    req.checkBody('full_name', 'First name is required.').notEmpty();

    req.sanitize("gender").trim();
    req.checkBody('gender', 'Select Gender.').notEmpty();

    req.sanitize("phone_number").trim();
    req.checkBody('phone_number', 'Valid Phone number is required.').isNumeric();

    req.sanitize("email").trim();
    req.checkBody('email', 'Valid Email is required.').isEmail();

    req.sanitize("password").trim();
    req.checkBody('password', 'Password is required.').notEmpty();
    // req.checkBody('password2', 'Passwords did not match.').equals(req.body.password);

    let errors = req.validationErrors();

    if (errors) {
        console.log("Validation error: " + JSON.stringify(errors));
        res.json({ success: false, msg: 'Failed to register user ', errors });

    } else {
        let newUser = new User({
            full_name: req.body.full_name,
            gender: req.body.gender,
            phone_number: req.body.phone_number,
            email: req.body.email,
            password: req.body.password
        });

        User.addUser(newUser, (err, user) => {
            if (err) {
                res.json({ success: false, message: 'Failed to register user', error: err });
            }
            res.json({
                success: true,
                msg: 'Registrations succesfull',
                user: user
            });
        });
    }
});


app.get("/server_all_users", (req, res) => {
    User.find({}, null, { sort: { '_id': -1 } }, (err, data) => {
        if (err) {
            res.send("Something went wrong in fetching the data from database.");
        }
        res.json({
            data: data
        });
    });
});


app.get("/login", (req, res) => {
    res.json({
        page: "login Root",
        msg: "Welcome to login file"
    });
});


app.post("/login", (req, res) => {
    console.log(req.body);

    req.sanitize("username");
    req.checkBody("username", "Enter valid Email address").isEmail();
    req.sanitize("password");
    req.checkBody("password", "Enter Password").notEmpty();

    let errors = req.validationErrors();

    if (errors) {
        console.log("Validation errorrs: " + JSON.stringify(errors));
        res.render("login", {
            activeClass: "login",
            errorsData: errors
        });
    } else {
        console.log("Everything is okay. \n");
        User.getUserByUsername(req.body.username, (err, userInfo) => {
            if (err) {
                console.log("Query execution failed: " + err);
                res.json({ success: false, msg: 'Query execution failed', error: err });
            }

            if (!userInfo) {
                console.log("No match found with that email: \n");
                res.json({ message: "No match found with that email" });
                res.json({ success: false, message: 'No match found with that email' });
            } else {
                console.log(userInfo);
                bcrypt.compare(req.body.password, userInfo.password, function (err, isMatch) {
                    if (err) {
                        console.log("Something went wrong in comparing passwords: " + err);
                        res.json({ success: false, message: 'Something went wrong in comparing passwords', error: err });
                    }
                    if (isMatch) {
                        console.log("Passwords Matched. \n");
                        // res.json({ message: "Passwords Matched" });

                        let userId = {
                            userId: userInfo._id
                        }

                        jwt.sign({ user: userId }, 'secretkey', { expiresIn: '1h' }, (err, token) => {
                            console.log("Generated token is: " + token);
                            res.json({ success: true, message: 'Passwords Matched', user: userInfo, token });
                        });

                    } else {
                        console.log("Passwords did not match ");
                        res.json({ success: false, message: 'Passwords did not match' });
                    }
                });
            }

        });
    }
});


/* Profile route */
app.get("/profile", verifyToken, (req, res) => {
    var decoded = req.token;
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if (err) {
            // res.sendStatus(403);
            res.json({
                success: false,
                message: "403 Forbidden at profile",
                error: err
            });
        } else {
            // console.log("Current user id " + JSON.stringify(authData));
            console.log("Current user id " + authData.user.userId);
            User.findOne({ _id: authData.user.userId }, (err, userInfo) => {
                if (err) {
                    console.log("Query execution failed: " + err);
                    res.json({ success: false, msg: 'Query execution failed', error: err });
                }

                if (!userInfo) {
                    console.log("No user found \n");
                    res.json({ success: false, message: 'No user found' });
                } else {
                    console.log(userInfo);
                }

                res.json({
                    success: true,
                    message: "Here is your profile...!",
                    user: userInfo
                });
            });
        }
        // res.send("Here is your profile...!");
    });
});


/* Profile route */
app.get("/all_users", verifyToken, (req, res) => {
    var decoded = req.token;
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if (err) {
            // res.sendStatus(403);
            res.json({
                success: false,
                message: "403 Forbidden at profile",
                error: err
            });
        } else {

            User.find({}, null, { sort: { '_id': -1 } }, (err, usersInfo) => {
                if (err) {
                    console.log("Query execution failed: " + err);
                    res.json({ success: false, msg: 'Query execution failed', error: err });
                }

                if (!usersInfo) {
                    console.log("No user found \n");
                    res.json({ message: "No user found" });
                    res.json({ success: false, message: 'No user found' });
                } else {
                    // console.log(usersInfo);
                }

                res.json({
                    success: true,
                    message: "Here is list of users...!",
                    users: usersInfo
                });
            });
        }
        // res.send("Here is your profile...!");
    });
});


app.post(("/user/delete/:id"), (req, res) => {
    // console.log(req.params);
    let deletableId = req.params.id;
    var result = "";
    console.log("Deletable user ID is: " + deletableId);
    User.findByIdAndRemove(deletableId, (err, userInfo) => {
        if (err) {
            console.log("Query execution failed: " + err);
            res.json({ success: false, message: 'Query execution failed', error: err });
        }

        if (!userInfo) {
            console.log("No user found \n");
            res.json({ success: false, message: 'No user found with provided ID' });
        } else {
            console.log(userInfo);
        }

        console.log("User deleted successfully...! \n");
        res.json({
            success: true,
            message: "User deleted successfully...!",
            user: userInfo
        });
    });
});





app.post(("/user/edit/"), (req, res) => {
    // console.log(req.params);
    let editableId = req.body.id;
    var result = "";
    // console.log("EditableId user ID is: " + editableId);
    User.findById(editableId, (err, userInfo) => {
        if (err) {
            console.log("Query execution failed: " + err);
            res.json({ success: false, message: 'Query execution failed', error: err });
        }

        if (!userInfo) {
            console.log("No user found \n");
            res.json({ success: false, message: 'No user found with provided ID' });
        } else {
            // console.log(userInfo);
        }

        //console.log("wohooo...! Record found \n");
        res.json({
            success: true,
            message: "wohooo...! Record found",
            user: userInfo
        });
    });
});


/* Settings route */
app.get("/settings", verifyToken, (req, res) => {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if (err) {
            // res.sendStatus(403);
            res.json({
                message: "403 Forbidden at profile",
                error: err
            });
        } else {
            res.json({
                message: "Here is your settings...!",
                authData
            });
        }
    });
    // res.send("Here is your profile...!");
});


function verifyToken(req, res, next) {
    var clientHeader = req.headers['authorization'];

    if (typeof clientHeader !== 'undefined') {
        //const client = clientHeader.split(' ');
        //const clientToken = client[1];
        req.token = clientHeader;
        next();
    } else {
        // res.sendStatus(403);
        res.json({
            success: false,
            message: "403 Forbidden at verification func"
        });
    }
}













// Assigning a port to app to listen
app.listen(port, () => {
    console.log("Server started at port: " + port);
});