import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ValidateService } from '../../services/validate.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { NgFlashMessageService } from 'ng-flash-messages';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  departmentId: any;
  user: Object = {
    userId: ""
  };
  full_name: String;
  gender: String;
  phone_number: Number;
  email: String;
  id: any;
  myImage: any;
  fileToUpload: File = null;


  constructor(
    private route: ActivatedRoute,
    private authService: AuthService,
    private router: Router,
    private flashMessage: NgFlashMessageService,
    private validateService: ValidateService,
  ) { }

  ngOnInit() {
    let id = this.route.snapshot.params['id'];
    this.departmentId = id;

    this.authService.getUserById(this.departmentId).subscribe(profile => {
      console.log(profile);
      if (profile.success) {
        this.user = profile.user;
        this.full_name = profile.user.full_name;
        this.gender = profile.user.gender;
        this.phone_number = profile.user.phone_number;
        this.email = profile.user.email;
        this.id = profile.user._id;
      } else {
        this.authService.logout();
        this.flashMessage.showFlashMessage({
          messages: [profile.message],
          dismissible: true,
          timeout: 3000,
          type: 'success'
        });
        this.router.navigate(['/login']);
        return false;
      }
    },
      err => {
        console.log(err);
        return false;
      });

  }


  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
  }



  onUpdateSubmit() {
    const user = {
      full_name: this.full_name,
      gender: this.gender,
      phone_number: this.phone_number,
      email: this.email,
      id: this.id,
      myImage: this.myImage
    }

    console.log(user);

    // Required Fields
    if (!this.validateService.validateUpdate(user)) {
      console.log("Please fill in all fields");
      this.flashMessage.showFlashMessage({
        messages: ['Please fill in all fields'],
        dismissible: true,
        timeout: 3000,
        // Type of flash message, it defaults to info and success, warning, danger types can also be used
        type: 'danger'
      });
      return false;
    }

    // Validate Email
    if (!this.validateService.validateEmail(user.email)) {
      console.log("Please Enter a valid email");
      this.flashMessage.showFlashMessage({
        messages: ['Please use a valid email'],
        dismissible: true,
        timeout: 3000,
        type: 'danger'
      });
      return false;
    }


    // Register user
    this.authService.updateUser(user, this.fileToUpload).subscribe(data => {
      if (data.success) {
        this.flashMessage.showFlashMessage({
          messages: [data.message],
          dismissible: true,
          timeout: 3000,
          type: 'success'
        });
        this.router.navigate(['/view/' + this.id]);
      } else {
        this.flashMessage.showFlashMessage({
          messages: [data.message],
          dismissible: true,
          timeout: 3000,
          type: 'danger'
        });
        this.router.navigate(['/dashboard']);
      }
    });


  }

}
