import { Component, OnInit } from '@angular/core';
import { ValidateService } from '../../services/validate.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { NgFlashMessageService } from 'ng-flash-messages';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username: String;
  password: String;

  constructor(
    private validateService: ValidateService,
    private authService: AuthService,
    private router: Router,
    private flashMessage: NgFlashMessageService
  ) { }

  ngOnInit() {
  }

  onLoginSubmit() {
    const user = {
      username: this.username,
      password: this.password
    }


    // Required Fields
    if (!this.validateService.validateLogin(user)) {
      console.log("Please fill in all fields");
      this.flashMessage.showFlashMessage({
        messages: ['Please fill in all fields'],
        dismissible: true,
        timeout: 3000,
        // Type of flash message, it defaults to info and success, warning, danger types can also be used
        type: 'danger'
      });
      return false;
    }

    // Validate Email
    if (!this.validateService.validateEmail(user.username)) {
      console.log("Please Enter a valid email");
      this.flashMessage.showFlashMessage({
        messages: ['Please use a valid email'],
        dismissible: true,
        timeout: 3000,
        type: 'danger'
      });
      return false;
    }


    this.authService.authenticateUser(user).subscribe(data => {
      if (data.success) {
        this.authService.storeUserData(data.token, data.user);
        this.flashMessage.showFlashMessage({
          messages: ['You are now logged in'],
          dismissible: true,
          timeout: 3000,
          type: 'success'
        });
        this.router.navigate(['profile']);
      } else {
        this.flashMessage.showFlashMessage({
          messages: [data.message],
          dismissible: true,
          timeout: 3000,
          type: 'danger'
        });
        this.router.navigate(['login']);
      }
    });
  }

}
