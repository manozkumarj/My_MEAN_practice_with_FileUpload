import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { NgFlashMessageService } from 'ng-flash-messages';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  departmentId: any;
  user: Object = {
    userId: ""
  };

  constructor(
    private route: ActivatedRoute,
    private authService: AuthService,
    private router: Router,
    private flashMessage: NgFlashMessageService
  ) { }


  ngOnInit() {
    let id = this.route.snapshot.params['id'];
    this.departmentId = id;


    this.authService.getUserById(this.departmentId).subscribe(profile => {
      console.log(profile);
      if (profile.success) {
        console.log(profile);
        this.user = profile.user;
      } else {
        this.authService.logout();
        this.flashMessage.showFlashMessage({
          messages: [profile.message],
          dismissible: true,
          timeout: 3000,
          type: 'success'
        });
        this.router.navigate(['/login']);
        return false;
      }
    },
      err => {
        console.log(err);
        return false;
      });

  }

}
