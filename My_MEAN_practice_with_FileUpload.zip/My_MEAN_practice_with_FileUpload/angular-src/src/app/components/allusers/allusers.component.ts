import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import * as $ from 'jquery';

@Component({
  selector: 'app-allusers',
  templateUrl: './allusers.component.html',
  styleUrls: ['./allusers.component.css']
})
export class AllusersComponent implements OnInit {
  users: Array<any>;
  $: any;

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit() {

    $(document).ready(function () {
      //  alert();

      $(".deleteUser").on("click", deleteUser);

      function deleteUser(authService) {
        //  alert(JSON.stringify(authService));
        var confirmation = confirm("Are you sure want to delete this user...?");
        if (confirmation) {
          var getUserId = $(this).attr("id");
          // alert(getUserId); // return false;
          $.ajax({
            type: "POST",
            url: "http://localhost:3000/user/delete/" + getUserId,
            beforeSend: function (xhr) {
              xhr.setRequestHeader("Authorization", "Basic");
            },
            success: function (response) {
              console.log("Done, Ajax call completed successfully" + response);
              if (response.success) {
                alert("Done, Ajax call completed successfully");
                $("#user_tr_" + getUserId).hide();
                // location.reload();
              } else {
                alert("Failed, Something went wrong in deleting the user");
              }
            }, error: function () {
              console.log("Error, ajax call failed...!");
              alert("Error, ajax call failed...!");
            }
          });
        }
        return false;
      }

    });

    this.authService.getUsers().subscribe(users => {
      //  console.log(users);
      this.users = users.users;
    },
      err => {
        console.log(err);
        return false;
      });
  }

}
