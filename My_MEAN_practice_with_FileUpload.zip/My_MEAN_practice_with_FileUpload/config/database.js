module.exports = {
    database: "mongodb://localhost:27017/nodewithjwt",
    secretKey: "1234567890"
};